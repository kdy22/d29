# GigaMEC - MANO Portal

## Requirements

> Maria DB 10.3.x\
> Prometheus 2.x\
> kube-ops-view

## Development

```bash
# Installing js package
npm i -D
# Creating a Bundle
./scripts/webpack.sh
# Running project
mvn spring-boot:run -D spring-boot.run.profiles=dev-docker -D spring.config.location=file:~/mano-portal/application.yml
# Port-forwarding
nohup kubectl port-forward --address 0.0.0.0 svc/kube-ops-kube-ops-view 15050:80 -n monitoring > kubeops.log < /dev/null &
nohup kubectl port-forward --address 0.0.0.0 svc/prometheus-k8s 17070:9090 -n monitoring > prometheus.log < /dev/null &
nohup kubectl port-forward --address 0.0.0.0 svc/alertmanager-main 9093 -n monitoring > alertmanager.log < /dev/null &
```

## Production

```bash
# Push to GitLab
# Use Jenkins[file] to deploy
helmsman -apply -f helmsman/giga-mec.toml -verbose -debug
```