#!/bin/bash

## install
helmsman -apply -f config/helmsman.toml -verbose -debug

## delete
# helmsman -destroy -f config/helmsman.toml -verbose -debug