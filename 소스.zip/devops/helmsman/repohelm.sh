#!/bin/bash

## --- chartmuseum on docker ---
# https://chartmuseum.com/docs/#configuration
docker run -d \
  -p 8879:8080 \
  --name localchart \
  --restart=always \
  -e DEBUG=1 \
  -e STORAGE=local \
  -e STORAGE_LOCAL_ROOTDIR=/charts \
  -e CONTEXT_PATH=/ \
  -v ~/chartstorage:/charts \
  chartmuseum/chartmuseum:latest
# curl -v localhost:8879
# helm repo add local http://localhost:8879
# helm repo update
# curl http://localhost:8879/api/charts/mano-portal

## --- chartmuseum on darwin ---
## https://github.com/helm/chartmuseum
# curl -fsSL https://raw.githubusercontent.com/fishworks/gofish/master/scripts/install.sh | bash
# gofish init
# gofish install chartmuseum
# curl -LO https://s3.amazonaws.com/chartmuseum/release/latest/bin/darwin/amd64/chartmuseum
# chmod +x ./chartmuseum
# chartmuseum \
# --debug \
# --port=8879 \
# --context-path=/ \
# --storage="local" \
# --storage-local-rootdir="/chartstorage" &

## --- servecm on cloud ---
## Installed plugin: servecm
# helm plugin install https://github.com/jdolitsky/helm-servecm

## Installed ChartMuseum
# helm servecm

## Start ChartMuseum web server
# Mac 의 문제
# --storage-local-rootdir="/chartstorage" \ Error: 500: mkdir /chartstorage: read-only file system
#--disable-statefiles : disable use of index-cache.yaml
# nohup \
# helm servecm --port=8879 --context-path=/localcharts \
# --storage="local" \
# --storage-local-rootdir="/Users/changsuim/chartstorage" \
# > servecm.log < /dev/null &

# helm repo add local http://127.0.0.1:8879/charts
# helm push ./chart/ local --force --context-path=/
# helm repo update
# helm search repo local
# helm show values local/mano-portal
# helm install local/mano-portal => helmsman

## https://chartmuseum.com/docs/
# DELETE /api/charts/<name>/<version> - delete a chart version (and corresponding provenance file)
# curl -XDELETE http://localhost:8879/localcharts/api/charts/mano-portal/latest
# => {"error":"remove /Users/changsuim/chartstorage/mano-portal-latest.tgz: no such file or directory"}
# curl -XDELETE http://localhost:8879/localcharts/api/charts/mano-portal/0.1.0
