# Helmsman version: v3.4.2

## Case 1
1. Run `helmsman -apply -f app1.toml` => success
2. Run `helmsman -apply -f app2.toml` => panic

## Case 2
1. Run `helmsman -apply -f app2.toml` => success
2. Run `helmsman -apply -f app1.toml` => panic

```bash
# Case 2
$ helmsman -apply -f app2.toml
...

$ helm ls --namespace test-ns
NAME    NAMESPACE    ...
app2    test-ns      ...
```

```bash
$ helmsman -apply -f app1.toml
...
2020-06-03 11:03:51 NOTICE: -------- PLAN starts here --------------
2020-06-03 11:03:51 WARNING: Untracked release [ app2 ] found and it will be deleted -- priority: -1000
2020-06-03 11:03:51 NOTICE: Release [ app1 ] version [ 0.0.1 ] will be installed in [ test-ns ] namespace -- priority: 0
2020-06-03 11:03:51 NOTICE: -------- PLAN ends here --------------
2020-06-03 11:03:51 INFO: Printing the commands of the current plan ...
helm uninstall app2 --namespace test-ns
helm upgrade app1 local/app1 --install --version 0.0.1 --namespace test-ns
2020-06-03 11:03:51 INFO: Sorting the commands in the plan based on priorities (order flags) ...
2020-06-03 11:03:51 INFO: Executing plan...
panic: runtime error: invalid memory address or nil pointer dereference
[signal SIGSEGV: segmentation violation code=0x1 addr=0x0 pc=0x18c4d1c]

goroutine 58 [running]:
github.com/Praqma/helmsman/internal/app.(*plan).exec.func1(0xc000350e80, 0xc000060ba0, 0x1b18f8a, 0x4, 0xc0003aa300, 0x4, 0x4, 0xc000024a50, 0x42, 0xfffffffffffffce0, ...)
	/go/src/github.com/Praqma/helmsman/internal/app/plan.go:119 +0x15c
created by github.com/Praqma/helmsman/internal/app.(*plan).exec
	/go/src/github.com/Praqma/helmsman/internal/app/plan.go:111 +0x4e2
```

```bash
$ helm ls --namespace test-ns
NAME    NAMESPACE    ...
app2    test-ns      ...
```

## Case 3
1. Run `helmsman -apply -f app2.toml` => success
2. Run `helmsman -apply -keep-untracked-releases -f app1.toml` => success
3. Run `helmsman -destroy -f app2.toml` => panic
4. Run `helmsman -destroy -keep-untracked-releases -f app2.toml` => success