#!/bin/bash
#
### https://www.lesstif.com/system-admin/rhel-centos-tomcat-service-booting-6979609.html
### https://m.blog.naver.com/PostView.nhn?blogId=diceworld&logNo=220295874000&proxyReferer=https:%2F%2Fwww.google.com%2F
# chkconfig: 2345 10 90
### chkconfig --add chartstorage
### chkconfig --list
#
### BEGIN INIT INFO
# Provides:          chartstorage
# Required-Start:    $local_fs $network $named $time $syslog
# Required-Stop:     $local_fs $network $named $time $syslog
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Description:       helm chart repository
### END INIT INFO

# /etc/rc.d/init.d/chartstorage => 자동으로 /etc/init.d/chartstorage 심볼릭 링크 생성'
# chmod +x chartstorage
# service chartstorage start
# service chartstorage stop

SCRIPT="helm servecm --port=8879 --context-path=/charts --storage='local' --storage-local-rootdir='/chartstorage'"
RUNAS="root"

PIDFILE=/var/run/chartstorage.pid
LOGFILE=/var/log/chartstorage.log

start() {
  if [ -f /var/run/$PIDNAME ] && kill -0 $(cat /var/run/$PIDNAME); then
    echo 'Service already running' >&2
    return 1
  fi
  echo 'Starting service…' >&2
  local CMD="$SCRIPT &> \"$LOGFILE\" & echo \$!"
  su -c "$CMD" $RUNAS > "$PIDFILE"
  echo 'Service started' >&2
}

stop() {
  if [ ! -f "$PIDFILE" ] || ! kill -0 $(cat "$PIDFILE"); then
    echo 'Service not running' >&2
    return 1
  fi
  echo 'Stopping service…' >&2
  kill -15 $(cat "$PIDFILE") && rm -f "$PIDFILE"
  echo 'Service stopped' >&2
}

uninstall() {
  echo -n "Are you really sure you want to uninstall this service? That cannot be undone. [yes|No] "
  local SURE
  read SURE
  if [ "$SURE" = "yes" ]; then
    stop
    rm -f "$PIDFILE"
    echo "Notice: log file is not be removed: '$LOGFILE'" >&2
    update-rc.d -f chartstorage remove
    rm -fv "$0"
  fi
}

# sync;sync;sync;sync;sync;
# poweroff
# reboot -- -r
# nohup helm servecm --port=8879 --context-path=/charts --storage="local" --storage-local-rootdir="/chartstorage" < /dev/null &

case "$1" in
  start)
    start
    ;;
  stop)
    stop
    ;;
  uninstall)
    uninstall
    ;;
  retart)
    stop
    start
    ;;
  *)
    echo "Usage: $0 {start|stop|restart|uninstall}"
esac
# https://gist.github.com/naholyr/4275302