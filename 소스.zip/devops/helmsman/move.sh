#!/bin/bash

### helmsman 설치
# 1. requirements
# - kubectl
# - helm (helm >=v2.10.0 for helmsman >= 1.6.0, helm >=v3.0.0 for helmsman >=v3.0.0)
# - helm-diff (helmsman >= 1.6.0)
#   (git이 있다면)
#   > helm plugin install https://github.com/databus23/helm-diff --version master
#   (git이 없다면)
curl -L https://github.com/databus23/helm-diff/releases/download/v3.1.1/helm-diff-linux.tgz | tar zx
mv diff/ /root/.local/share/helm/plugins/
# 2. install on Linux (https://github.com/Praqma/helmsman/blob/master/README.md)
curl -L https://github.com/Praqma/helmsman/releases/download/v3.4.2/helmsman_3.4.2_linux_amd64.tar.gz | tar zx
mv helmsman /usr/local/bin/helmsman

### Deploy
# 1. mec-repo
ssh root@221.153.191.33
# 한번에 옮기기 위해 디렉토리 생성
mkdir /root/moveto
cd /root/moveto

# 1-1. docker 이미지 저장
docker save -o mano-portal.tar mano-portal:0.0.7
docker save -o mano-sim.tar mec-repo:5000/broker-sim:0.0.1
docker save -o mec-vim.tar mec-vim:0.2.3
docker save -o mec-broker.tar mec-broker:0.2.4

# 1-2. helm 차트 저장
cp -i -r /root/mec/2020/chart/rabbitmq.0420 /root/moveto/charts
mv /root/moveto/charts/rabbitmq.0420 /root/moveto/charts/rabbitmq
cp -i -r /root/mec/2020/chart/mariadb /root/moveto/charts
mkdir /root/moveto/charts/mano-portal
cp -i -r /var/lib/jenkins/workspace/mano-portal/chart/* /root/moveto/charts/mano-portal
cp -i -r /root/wizontech/giga-vim/giga-vim/mano-vim /root/moveto/charts
mv /root/moveto/charts/mano-vim /root/moveto/charts/mec-vim
cp -i -r /root/wizontech/giga-broker/giga-broker/mano-broker /root/moveto/charts
mv /root/moveto/charts/mano-broker /root/moveto/charts/mec-broker

# local
docker build -f Dockerfile . --tag mano-portal:0.0.7 --no-cache

# 1-3. mec-repo -> mec-w6
# (mec-w6) watch ls -al /root/moveto
scp -P 23022 -v -r /root/moveto root@118.131.245.86:/root

# 1-4. mec-w6 -> giga-ansan1
# (giga-ansan1) watch ls -al /root/moveto
ssh root@118.131.245.86 -p 23022
scp -v -r /root/moveto root@192.168.213.241:/root
scp -v -r /root/moveto root@192.168.213.243:/root

# 2. giga-ansan1 (giga-chungju1)
# 안산: ssh root@192.168.213.241
# 청주: ssh root@192.168.213.243
cd /root/moveto

# 2-1. docker image load-push registry
# cd /etc/systemd/system/docker.service.d
# systemctl status docker
# systemctl reload docker
# > docker.service changed on disk. Run 'systemctl daemon-reload' to reload units.
# systemctl daemon-reload
# systemctl list-units | grep docker
# vi http_proxy.conf
# [Service]
# Environment="HTTP_PROXY=http://192.168.213.243:5000/"
# vi /etc/docker/daemon.json
# {"insecure-registries" : ["giga-chungju1:5000"]}
# vi docker-dns.conf
# load: local에 docker image 적재
# push: registry에 docker image 적재
docker load -i /root/moveto/mano-portal.tar
docker load -i /root/moveto/mec-vim.tar
docker load -i /root/moveto/mec-broker.tar

docker tag mano-portal:0.0.7 giga-chungju1:5000/mano-portal:0.0.7
docker tag mec-vim:0.2.3 giga-chungju1:5000/mec-vim:0.2.3
docker tag mec-broker:0.2.4 giga-chungju1:5000/mec-broker:0.2.4

docker push giga-chungju1:5000/mano-portal:0.0.7
docker push giga-chungju1:5000/mec-vim:0.2.3
docker push giga-chungju1:5000/mec-broker:0.2.4

# curl -X GET localhost:5000/v2/_catalog
# curl -X GET localhost:5000/v2/mano-portal/tags/list
# curl -X GET localhost:5000/v2/mano-portal/manifests/0.0.7

# 2-2. chartmuseum 실행
# --debug \
nohup chartmuseum \
--port=8879 \
--context-path=/charts \
--storage="local" \
--storage-local-rootdir="/chartstorage" < /dev/null &

# chartmuseum \
# --port=8879 \
# --context-path=/charts \
# --storage="local" \
# --storage-local-rootdir="/chartstorage" &

# helm servecm \
# --port=8879 \
# --context-path=/charts \
# --storage="local" \
# --storage-local-rootdir="/chartstorage" &
# => ps 를 확인하면 결국 servecm 플러그인이 chartmuseum 실행

# helm package ./mano-portal

# 2-3. chartmuseum에 helm chart 저장
helm push -f /root/moveto/charts/mariadb local
helm push -f /root/moveto/charts/rabbitmq local
helm push -f /root/moveto/charts/mano-portal local
helm push -f /root/moveto/charts/mec-vim local
helm push -f /root/moveto/charts/mec-broker local
helm repo update
helm search repo local
# => /etc/hosts 192.168.213.243 giga-chungju1
# curl -v giga-chungju1:8879/charts/index.yaml
# curl -v -X DELETE giga-chungju1:8879/charts/api/charts/mano-broker/0.1.0
# > {"deleted":true}
# helm repo update

# 2-4. helmsman-차트 설치
helmsman -apply -keep-untracked-releases -f /root/moveto/helmsman/giga-mec.toml -verbose -debug
# helmsman -apply -keep-untracked-releases -no-ns -f /root/moveto/helmsman/portal.toml -verbose -debug
# helmsman -apply -keep-untracked-releases -no-ns -f /root/moveto/helmsman/vim.toml -verbose -debug
# helmsman -apply -keep-untracked-releases -no-ns -f /root/moveto/helmsman/broker.toml -verbose -debug

# 2-5. Upgrade release (unless the release is protected or deployed in a protected namespace)
helmsman -apply -f /root/moveto/helmsman/giga-mec.toml -verbose -debug
# helmsman -apply -no-ns -f /root/moveto/helmsman/portal.toml -verbose -debug
# helmsman -apply -no-ns -f /root/moveto/helmsman/vim.toml -verbose -debug
# helmsman -apply -no-ns -f /root/moveto/helmsman/broker.toml -verbose -debug

# 2-6. helmsman-차트 삭제
helmsman -destroy -f /root/moveto/helmsman/giga-mec.toml -verbose -debug
# helmsman -destroy -f /root/moveto/helmsman/portal.toml -verbose -debug
# helmsman -destroy -f /root/moveto/helmsman/broker.toml -verbose -debug
# helmsman -destroy -f /root/moveto/helmsman/vim.toml -verbose -debug

# -keep-untracked-releases 플래그가 없을 경우
# 2020-06-02 17:47:00 INFO: Executing plan...
# panic: runtime error: invalid memory address or nil pointer dereference
# [signal SIGSEGV: segmentation violation code=0x1 addr=0x0 pc=0xcc57ac]

# goroutine 53 [running]:
# github.com/Praqma/helmsman/internal/app.(*plan).exec.func1(0xc00048a9f0, 0xc0004d03c0, 0xf19959, 0x4, 0xc0004ba640, 0x4, 0x4, 0xc0004961e0, 0x41, 0xfffffffffffffce0, ...)
# 	/go/src/github.com/Praqma/helmsman/internal/app/plan.go:119 +0x15c
# created by github.com/Praqma/helmsman/internal/app.(*plan).exec
# 	/go/src/github.com/Praqma/helmsman/internal/app/plan.go:111 +0x4e2

# prom(-2, wait) -> kube-ops-view(-1)
# maria, rabbit(-2, wait) -> portal(-1) -> vim(0) -> broker(0)