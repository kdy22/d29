#! /bin/bash

# https://github.com/coreos/prometheus-operator/blob/master/scripts/minikube-rbac.yaml
# minikube stop
minikube delete

# docker desktop이 켜지기 전에 minikube를 실행시키면 prometheus에 붙질 않고 url.openconnection에서 timeout
# docker desktop -> minikube
# https://gist.github.com/F21/08bfc2e3592bed1e931ec40b8d2ab6f5
# https://minikube.sigs.k8s.io/docs/handbook/config/
# https://minikube.sigs.k8s.io/docs/drivers/
# https://kubernetes.io/ko/docs/setup/learning-environment/minikube/
# https://docs.docker.com/network/proxy/#configure-the-docker-client
# https://docs.docker.com/docker-for-mac/networking/#use-cases-and-workarounds
# docker system info
# docker for mac - Preferences - Resources - Proxies - Manual off
# vi /etc/hosts
# vi /etc/resolv.conf
# vi ~/.docker/config.json
# https://minikube.sigs.k8s.io/docs/handbook/host-access/
# minikube ssh "route -n | grep ^0.0.0.0 | awk '{ print \$2 }'"
# > 192.168.64.1
# minikube ssh
# curl 192.168.64.1:5000/v2/_catalog (docker registry responds)
# curl 192.168.64.1:8879 (chartmuseum responds)
# https://hasura.io/blog/sharing-a-local-registry-for-minikube-37c7240d0615/
# https://minikube.sigs.k8s.io/docs/handbook/registry/
# insecure-registry="daemon.json"
# minikube ssh "route -n | grep ^0.0.0.0 | awk '{ print \$2 }'"
# minikube ssh
# route -n | grep ^0.0.0.0 | awk '{ print $2 }'
minikube start \
--kubernetes-version=v1.16.0 \
--driver=hyperkit \
--container-runtime=docker \
--extra-config=kubelet.streaming-connection-idle-timeout=0
# --insecure-registry="127.0.0.1:5000" \
# --addons registry
nohup kubectl port-forward --address 0.0.0.0 svc/registry 5000:80 -n kube-system > registry.log < /dev/null &
# --docker-env http_proxy=http://192.168.64.1:3128 \
# --docker-env http_proxy=http://host.docker.internal:3128 \
# --docker-env https_proxy=https://host.docker.internal:3129 \
# --docker-env no_proxy=localhost,127.0.0.1,192.168.64.1
# --addons dashboard \
# --addons logviewer \
# --addons metrics-server \
# --addons istio \
# --addons istio-provisioner \
## default-storageclass와 storage-provisioner 은 start 하자마자 기본 생성
# minikube start --kubernetes-version=v1.17.0 --driver=hyperkit
# minikube config set extra-config kubelet.streaming-connection-idle-timeout=0
# minikube start --kubernetes-version=v1.18.0 --driver=hyperkit
# minikube start --kubernetes-version=v1.18.0 --driver=hyperkit --extra-config=apiserver.authorization-mode=RBAC --v=5
# minikube start --nfs-share
# kubectl create clusterrolebinding add-on-cluster-admin --clusterrole=cluster-admin --serviceaccount=kube-system:default

# minikube config
minikube status
minikube dashboard

# https://stackoverflow.com/questions/52310599/what-does-minikube-docker-env-mean
# eval "$(minikube docker-env)"

# kubectl apply -f op-dev/kubernetes//minikube/minikube-rbac.yaml