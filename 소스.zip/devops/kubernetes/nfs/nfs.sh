#! /bin/bash

kubectl create ns gigamec-mano

# https://github.com/kubernetes-incubator/external-storage/blob/master/nfs/README.md
kubectl delete sa nfs-provisioner -n gigamec-mano
kubectl delete svc nfs-provisioner -n gigamec-mano
kubectl delete deploy nfs-provisioner -n gigamec-mano
kubectl delete clusterroles nfs-provisioner-runner  # warning: deleting cluster-scoped resources, not scoped to the provided namespace
kubectl delete clusterrolebindings run-nfs-provisioner # warning: deleting cluster-scoped resources, not scoped to the provided namespace
kubectl delete roles leader-locking-nfs-provisioner -n gigamec-mano
kubectl delete rolebindings leader-locking-nfs-provisioner -n gigamec-mano
kubectl delete sc example-nfs # warning: deleting cluster-scoped resources, not scoped to the provided namespace
kubectl delete pvc nfs -n gigamec-mano

kubectl create --filename ~/mano-portal/op-dev-vm/kubernetes/nfs/deployment.yaml --namespace gigamec-mano
# serviceaccount/nfs-provisioner created
# service/nfs-provisioner created
# deployment.apps/nfs-provisioner created
kubectl create --filename ~/mano-portal/op-dev-vm/kubernetes/nfs/rbac.yaml --namespace gigamec-mano
# clusterrole.rbac.authorization.k8s.io/nfs-provisioner-runner created
# clusterrolebinding.rbac.authorization.k8s.io/run-nfs-provisioner created
# role.rbac.authorization.k8s.io/leader-locking-nfs-provisioner created
# rolebinding.rbac.authorization.k8s.io/leader-locking-nfs-provisioner created
kubectl create --filename ~/mano-portal/op-dev-vm/kubernetes/nfs/class.yaml --namespace gigamec-mano
# storageclass.storage.k8s.io/example-nfs created
kubectl create --filename ~/mano-portal/op-dev-vm/kubernetes/nfs/claim.yaml --namespace gigamec-mano
# persistentvolumeclaim/nfs created

# https://github.com/kubernetes/examples/tree/master/staging/volumes/nfs
# https://matthewpalmer.net/kubernetes-app-developer/articles/kubernetes-volumes-example-nfs-persistent-volume.html