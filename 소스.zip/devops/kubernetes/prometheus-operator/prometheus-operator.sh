#! /bin/bash


# https://github.com/coreos/kube-prometheus
## v0.3.0 => kubernetes 1.14-1.17
# git clone -b v0.3.0 https://github.com/coreos/kube-prometheus.git
## v0.4.0 => kubernetes 1.16-1.17
# git clone -b v0.4.0 https://github.com/coreos/kube-prometheus.git
## v0.5.0 => kubernetes 1.17-1.18
# git clone -b v0.5.0 https://github.com/coreos/kube-prometheus.git

kubectl delete --ignore-not-found=true -f manifests/ -f manifests/setup

kubectl create -f manifests/setup
# namespace/monitoring created
# customresourcedefinition.apiextensions.k8s.io/alertmanagers.monitoring.coreos.com created
# customresourcedefinition.apiextensions.k8s.io/podmonitors.monitoring.coreos.com created
# customresourcedefinition.apiextensions.k8s.io/prometheuses.monitoring.coreos.com created
# customresourcedefinition.apiextensions.k8s.io/prometheusrules.monitoring.coreos.com created
# customresourcedefinition.apiextensions.k8s.io/servicemonitors.monitoring.coreos.com created
# customresourcedefinition.apiextensions.k8s.io/thanosrulers.monitoring.coreos.com created
# clusterrole.rbac.authorization.k8s.io/prometheus-operator created
# clusterrolebinding.rbac.authorization.k8s.io/prometheus-operator created
# deployment.apps/prometheus-operator created
# service/prometheus-operator created
# serviceaccount/prometheus-operator created

kubectl create -f manifests/
# alertmanager.monitoring.coreos.com/main created
# secret/alertmanager-main created
# service/alertmanager-main created
# serviceaccount/alertmanager-main created
# servicemonitor.monitoring.coreos.com/alertmanager created
# secret/grafana-datasources created
# configmap/grafana-dashboard-apiserver created
# configmap/grafana-dashboard-cluster-total created
# configmap/grafana-dashboard-controller-manager created
# configmap/grafana-dashboard-k8s-resources-cluster created
# configmap/grafana-dashboard-k8s-resources-namespace created
# configmap/grafana-dashboard-k8s-resources-node created
# configmap/grafana-dashboard-k8s-resources-pod created
# configmap/grafana-dashboard-k8s-resources-workload created
# configmap/grafana-dashboard-k8s-resources-workloads-namespace created
# configmap/grafana-dashboard-kubelet created
# configmap/grafana-dashboard-namespace-by-pod created
# configmap/grafana-dashboard-namespace-by-workload created
# configmap/grafana-dashboard-node-cluster-rsrc-use created
# configmap/grafana-dashboard-node-rsrc-use created
# configmap/grafana-dashboard-nodes created
# configmap/grafana-dashboard-persistentvolumesusage created
# configmap/grafana-dashboard-pod-total created
# configmap/grafana-dashboard-prometheus-remote-write created
# configmap/grafana-dashboard-prometheus created
# configmap/grafana-dashboard-proxy created
# configmap/grafana-dashboard-scheduler created
# configmap/grafana-dashboard-statefulset created
# configmap/grafana-dashboard-workload-total created
# configmap/grafana-dashboards created
# deployment.apps/grafana created
# service/grafana created
# serviceaccount/grafana created
# servicemonitor.monitoring.coreos.com/grafana created
# clusterrole.rbac.authorization.k8s.io/kube-state-metrics created
# clusterrolebinding.rbac.authorization.k8s.io/kube-state-metrics created
# deployment.apps/kube-state-metrics created
# service/kube-state-metrics created
# serviceaccount/kube-state-metrics created
# servicemonitor.monitoring.coreos.com/kube-state-metrics created
# clusterrole.rbac.authorization.k8s.io/node-exporter created
# clusterrolebinding.rbac.authorization.k8s.io/node-exporter created
# daemonset.apps/node-exporter created
# service/node-exporter created
# serviceaccount/node-exporter created
# servicemonitor.monitoring.coreos.com/node-exporter created
# apiservice.apiregistration.k8s.io/v1beta1.metrics.k8s.io created
# clusterrole.rbac.authorization.k8s.io/prometheus-adapter created
# clusterrole.rbac.authorization.k8s.io/system:aggregated-metrics-reader created
# clusterrolebinding.rbac.authorization.k8s.io/prometheus-adapter created
# clusterrolebinding.rbac.authorization.k8s.io/resource-metrics:system:auth-delegator created
# clusterrole.rbac.authorization.k8s.io/resource-metrics-server-resources created
# configmap/adapter-config created
# deployment.apps/prometheus-adapter created
# rolebinding.rbac.authorization.k8s.io/resource-metrics-auth-reader created
# service/prometheus-adapter created
# serviceaccount/prometheus-adapter created
# clusterrole.rbac.authorization.k8s.io/prometheus-k8s created
# clusterrolebinding.rbac.authorization.k8s.io/prometheus-k8s created
# servicemonitor.monitoring.coreos.com/prometheus-operator created
# prometheus.monitoring.coreos.com/k8s created
# rolebinding.rbac.authorization.k8s.io/prometheus-k8s-config created
# rolebinding.rbac.authorization.k8s.io/prometheus-k8s created
# rolebinding.rbac.authorization.k8s.io/prometheus-k8s created
# rolebinding.rbac.authorization.k8s.io/prometheus-k8s created
# role.rbac.authorization.k8s.io/prometheus-k8s-config created
# role.rbac.authorization.k8s.io/prometheus-k8s created
# role.rbac.authorization.k8s.io/prometheus-k8s created
# role.rbac.authorization.k8s.io/prometheus-k8s created
# prometheusrule.monitoring.coreos.com/prometheus-k8s-rules created
# service/prometheus-k8s created
# serviceaccount/prometheus-k8s created
# servicemonitor.monitoring.coreos.com/prometheus created
# servicemonitor.monitoring.coreos.com/kube-apiserver created
# servicemonitor.monitoring.coreos.com/coredns created
# servicemonitor.monitoring.coreos.com/kube-controller-manager created
# servicemonitor.monitoring.coreos.com/kube-scheduler created
# servicemonitor.monitoring.coreos.com/kubelet created

kubectl get all -n monitoring


nohup kubectl port-forward --address 0.0.0.0 svc/prometheus-k8s 9090 -n monitoring > prometheus.log < /dev/null &
nohup kubectl port-forward --address 0.0.0.0 svc/grafana 3000 -n monitoring > grafana.log < /dev/null &
nohup kubectl port-forward --address 0.0.0.0 svc/alertmanager-main 9093 -n monitoring > alertmanager.log < /dev/null &

# https://bcho.tistory.com/1270