#! /bin/bash

helm install kubeops ~/mano-portal/op-dev-vm/helm/kube-ops-view/ -n monitoring