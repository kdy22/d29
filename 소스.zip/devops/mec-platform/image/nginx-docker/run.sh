#!/bin/bash

/nginx/nginx

/nginx/idle.sh
