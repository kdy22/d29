cp ../../mec/hiredis_linux/redis-4.0.11/src/redis-server ./
