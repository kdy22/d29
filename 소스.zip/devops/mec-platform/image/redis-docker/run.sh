#!/bin/bash

/nginx/redis-server
