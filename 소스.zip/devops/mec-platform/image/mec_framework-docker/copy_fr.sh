 cp ../../mec/Linux/mec_framework ./
