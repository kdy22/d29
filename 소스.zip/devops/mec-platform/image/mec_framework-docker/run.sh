#!/bin/bash
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/root/mec/libfcgi/.libs

/root/mec/cgi-fcgi/cgi-fcgi -start -connect :8000 mec_framework
/nginx/idle.sh
