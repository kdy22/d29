#!/bin/bash

/nginx/test_pub_app
/nginx/idle.sh

