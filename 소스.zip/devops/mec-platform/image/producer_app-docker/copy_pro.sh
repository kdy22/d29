cp ../../mec/Linux/test/test_pub_app ./
