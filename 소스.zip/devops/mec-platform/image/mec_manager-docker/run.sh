#!/bin/bash
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/root/mec/libfcgi/.libs
/root/mec/cgi-fcgi/cgi-fcgi -start -connect :9000 mec_manager
/nginx/idle.sh
