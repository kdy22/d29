 cp ../../mec/Linux/mec_manager ./
