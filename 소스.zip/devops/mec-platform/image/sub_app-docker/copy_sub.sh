cp ../../mec/Linux/test/test_sub_app ./
