#!/bin/bash

sleep 1

/nginx/test_sub_app

sleep 1
