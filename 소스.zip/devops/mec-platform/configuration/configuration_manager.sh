# curl -d @mec_manager_test1.json http://221.153.191.42:30201/mecmanager/configuration
# curl -d @mec_manager_test2.json http://221.153.191.42:30201/mecmanager/configuration

curl -d @mec_manager_test1.json http://localhost:10201/mecmanager/configuration
curl -d @mec_manager_test2.json http://localhost:10201/mecmanager/configuration