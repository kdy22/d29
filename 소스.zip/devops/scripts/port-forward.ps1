Start-Process -NoNewWindow kubectl "port-forward --address 0.0.0.0 svc/kubernetes-dashboard 11010:80 -n kubernetes-dashboard"
# istio kiali : 12020
# istio tracing(jaeger) : 13030
# istio zipkin (reserve) : 14040
Start-Process -NoNewWindow kubectl "port-forward --address 0.0.0.0 svc/opsview-kube-ops-view 15050:80 -n monitoring"
Start-Process -NoNewWindow kubectl "port-forward --address 0.0.0.0 svc/grafana 16060:3000 -n monitoring"
Start-Process -NoNewWindow kubectl "port-forward --address 0.0.0.0 svc/prometheus-k8s 17070:9090 -n monitoring"
Start-Process -NoNewWindow kubectl "port-forward --address 0.0.0.0 svc/alertmanager-main 9093 -n monitoring"
# jenkins : 18080
# Start-Process -NoNewWindow kubectl "port-forward --address 0.0.0.0 svc/portal-mano-portal 19090:10080 -n gigamec-mano"

# netstat -ano | findStr "15050"
# taskkill /F /PID <pid_number>

# Never
# Stop-Process -ID PID -Force # Hang

# maven
# mvn spring-boot:run -D spring-boot.run.profiles=dev-docker -D spring.config.location=file:~/mano-portal/application.yml