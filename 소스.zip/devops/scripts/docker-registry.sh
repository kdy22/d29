#!/bin/bash

# /usr/lib/systemd/system/docker.service
# ~/.docker/config.json
# /etc/docker/daemon.json

## minikube docker-env
eval "$(minikube docker-env)"
## start registry on minikube
# https://docs.docker.com/registry/configuration/
docker run \
--detach \
--publish 5000:5000 \
--restart=always \
--name registry \
--env REGISTRY_STORAGE_FILESYSTEM_ROOTDIRECTORY=/root/images \
--env REGISTRY_STORAGE_DELETE_ENABLED=true \
registry:2

# or exec
# curl -X DELETE localhost:5000/v2/mano-portal/manifests/0.0.7
# {"errors":[{"code":"UNSUPPORTED","message":"The operation is unsupported."}]}
docker exec -it registry sh
cd /var/lib/registry
# if you set REGISTRY_STORAGE_FILESYSTEM_ROOTDIRECTORY
cd /root/images
rm -rf <repositories_name>

# vi /etc/docker/registry/config.yml
# storage:
#   delete:
#     enabled: true
# registry serve /etc/docker/registry/config.yml

# push mano-portal
PORTAL="portal"
NAMESPACE="gigamec-mano"
REPOSITORY="localhost"
# docker exec registry ip route sh
PORT="5000"
IMAGE_NAME="mano-portal"
DEL_VERSION="0.0.6"
VERSION="0.0.7"

echo "pwd :"`pwd`

# helm ls --all-namespaces | grep $PORTAL && helm uninstall $PORTAL --namespace $NAMESPACE
docker rmi --force $IMAGE_NAME $IMAGE_NAME:latest $IMAGE_NAME:$DEL_VERSION $REPOSITORY:$PORT/$IMAGE_NAME:$DEL_VERSION
docker build --file ./Dockerfile . --tag $IMAGE_NAME:latest --tag $IMAGE_NAME:$VERSION --no-cache
docker tag $IMAGE_NAME:$VERSION $REPOSITORY:$PORT/$IMAGE_NAME:$VERSION

# minikube ssh
docker push $REPOSITORY:$PORT/$IMAGE_NAME:$VERSION

echo "EXIT"

exit 0

# https://docs.docker.com/machine/install-machine/
# base=https://github.com/docker/machine/releases/download/v0.16.0 &&
#  curl -L $base/docker-machine-$(uname -s)-$(uname -m) >/usr/local/bin/docker-machine &&
#  chmod +x /usr/local/bin/docker-machine
## reset
# eval "$(docker-machine env --unset)"

# connection refused?
# vi ~/.docker/daemon.json
# { "insecure-registries" : [ "localhost:5000", "127.0.0.1:5000", "0.0.0.0:5000" ], "experimental": false, "debug": true }
# vi /etc/hosts
# docker ps: 0.0.0.0:5000->5000/tcp
# systemctl restart docker
# curl -v http://localhost:5000/v2/mano-portal/tags/list