FORMAT="\
ID\t{{.ID}}\n\
NAME\t{{.Names}}\n\
IMAGE\t{{.Image}}\n\
PORTS\t{{.Ports}}\n\
COMMAND\t{{.Command}}\n\
CREATED\t{{.CreatedAt}}\n\
STATUS\t{{.Status}}\n"

docker ps --format=$FORMAT