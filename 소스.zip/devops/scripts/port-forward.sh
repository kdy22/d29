#!/bin/bash
# kubelet --streaming-connection-idle-timeout=0

nohup kubectl port-forward --address 0.0.0.0 svc/kubernetes-dashboard 11010:80 -n kubernetes-dashboard > dashboard.log < /dev/null &
# istio kiali : 12020
# istio tracing(jaeger) : 13030
# istio zipkin (reserve) : 14040
nohup kubectl port-forward --address 0.0.0.0 svc/kube-ops-kube-ops-view 15050:80 -n monitoring > kubeops.log < /dev/null &
nohup kubectl port-forward --address 0.0.0.0 svc/grafana 16060:3000 -n monitoring > grafana.log < /dev/null &
nohup kubectl port-forward --address 0.0.0.0 svc/prometheus-k8s 17070:9090 -n monitoring > prometheus.log < /dev/null &
# nohup kubectl port-forward --address 0.0.0.0 svc/prom-prometheus-operator-prometheus 17070:9090 -n monitoring > prometheus.log < /dev/null &
nohup kubectl port-forward --address 0.0.0.0 svc/alertmanager-main 9093 -n monitoring > alertmanager.log < /dev/null &
# jenkins : 18080
nohup kubectl port-forward --address 0.0.0.0 svc/portal-mano-portal 19090:10080 -n gigamec-mano > portal.log < /dev/null &
# nohup kubectl port-forward --address 0.0.0.0 svc/portal-mano-portal 19090:10080 -n gigamec-mano &
# kubectl port-forward --address 0.0.0.0 svc/portal-mano-portal 19090:10080 -n gigamec-mano &

nohup kubectl port-forward --address 0.0.0.0 svc/registry 31000:80 -n kube-system > test.log < /dev/null &
## check
# curl -XGET http://221.153.191.33:19090

## delete
# ps -elf | grep port-forward
# lsof -i :19090
# kill -9 <PID>