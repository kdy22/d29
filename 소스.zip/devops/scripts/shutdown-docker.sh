#! /bin/bash

docker stop mano-portal_docker-spring_1 mano-portal_docker-mariadb_1
docker rm mano-portal_docker-spring_1 mano-portal_docker-mariadb_1
docker rmi mano-portal mariadb

echo "EXIT"
exit 0
## shutdown.sh -> Mac OS X 스크립트 실행
## ./shutdown.sh -> 해당 디렉토리 스크립트 실행