#! /bin/bash

## use docker
docker run \
--name maria \
-p 3306:3306 \
--restart=always \
-v /Users/changsuim/mano-portal/devops/helm/mariadb/files/docker-entrypoint-initdb.d/user.sql:/docker-entrypoint-initdb.d/user.sql \
-e MYSQL_ROOT_PASSWORD=testmaria \
-d \
mariadb:10.3.23-bionic

# docker build -f ./Dockerfile . -t mano-portal
# docker run mano-portal -it -d -p 10080:10080 --name mano-portal
## use docker-compose
## https://docs.docker.com/compose/reference/up/
# docker-compose up --build
## detach
# docker-compose up --build -d
## do not start
docker-compose up --no-start
docker-compose start

## use helm-kube deploy
## version 2
# docker save -o mano-portal.tar mano-portal
# docker load -i mano-portal.tar
# helm install ~/helm/mano-portal -n <namaspace>
## helm install mariadb <...>

echo "EXIT"
exit 0
## Linux, Mac OS X
## chmod +x ./build.sh
## ./build.sh