#! /bin/bash

eval $(minikube docker-env)
LOCAL_PATH=$(echo $PATH | grep -c /usr/local/bin)
MARIA="maria"
PORTAL="portal"
NAMESPACE="gigamec-mano"
IMAGE="mano-portal"
# docker config.json
# {
#   "experimental": false,
#   "debug": true,
#   "insecure-registries": [
#     "localhost:5000"
#   ]
# }
REPOSITORY="localhost:5000/mano-portal"

# echo $PATH

# ## helm
# if [ $LOCAL_PATH -eq 0 ]
#   then
#     export PATH=$PATH:/usr/local/bin
# fi

# echo $PATH

# helm ls --all-namespaces | grep maria && helm uninstall maria --namespace $NAMESPACE
# helm ls --all-namespaces | grep portal && helm uninstall portal --namespace $NAMESPACE

# docker rmi --force $REPOSITORY

docker build -f ./devops/Dockerfile . -t $REPOSITORY
# docker save -o mano-portal.tar $REPOSITORY

echo "EXIT"
exit 0
## Linux, Mac OS X
## chmod +x ./build-image.sh
## ./build-image.sh
