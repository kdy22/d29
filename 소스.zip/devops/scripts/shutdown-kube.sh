#! /bin/bash
echo $MARIA
MARIA="maria"
PORTAL="mano-portal"
NAMESPACE="gigamec-mano"
helm uninstall $PORTAL --namespace $NAMESPACE
helm uninstall $MARIA --namespace $NAMESPACE

# RUNNING_MARIA=$(kubectl get po -n $NAMESPACE | grep $MARIA | awk '{print $1}')
# RUNNING_PORTAL=$(kubectl get po -n $NAMESPACE | grep $PORTAL | awk '{print $1}')
# helm del --purge $RUNNING_PORTAL $RUNNING_MARIA

# unset MARIA
# unset PORTAL
# unset NAMESPACE

echo "EXIT"
exit 0
## shutdown.sh -> Mac OS X 스크립트 실행
## ./shutdown.sh -> 해당 디렉토리 스크립트 실행