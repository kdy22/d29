#!/bin/bash
nohup kubectl port-forward --address 0.0.0.0 svc/portal-mano-portal 19090:10080 -n gigamec-mano > portal.log < /dev/null &
# nohup kubectl port-forward --address 0.0.0.0 svc/portal-mano-portal 19090:10080 -n gigamec-mano &
# kubectl port-forward --address 0.0.0.0 svc/portal-mano-portal 19090:10080 -n gigamec-mano &

## check
# curl -XGET http://221.153.191.33:19090

## delete
# ps -elf | grep port-forward
# lsof -i :19090
# kill -9 <PID>