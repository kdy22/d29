#! /bin/bash

# PORTAL="portal"
# NAMESPACE="gigamec-mano"

REPOSITORY="mec-repo"
PORT="5000"
IMAGE_NAME="mano-portal"
DEL_VERSION="0.0.6"
VERSION="0.0.7"

echo "pwd :"`pwd`

# helm ls --all-namespaces | grep $PORTAL && helm uninstall $PORTAL --namespace $NAMESPACE
docker rmi --force $IMAGE_NAME $IMAGE_NAME:latest $IMAGE_NAME:$DEL_VERSION $REPOSITORY:$PORT/$IMAGE_NAME:$DEL_VERSION
docker build --file ./Dockerfile . --tag $IMAGE_NAME:latest --tag $IMAGE_NAME:$VERSION --no-cache
docker tag $IMAGE_NAME:$VERSION $REPOSITORY:$PORT/$IMAGE_NAME:$VERSION
docker push $REPOSITORY:$PORT/$IMAGE_NAME:$VERSION

echo "EXIT"

exit 0