#! /bin/bash

MARIA="maria"
PORTAL="portal"
NAMESPACE="gigamec-mano"
HELM_MARIA=$(helm ls -n $NAMESPACE | grep -c $MARIA)

helm repo update
helm search repo local
helm push -f ./chart local

echo "pwd :"`pwd`
echo "Helm Maria :" $HELM_MARIA
if [ $HELM_MARIA -eq 0 ]
  then
    KUBE_MARIA=$(kubectl get po -n $NAMESPACE | grep $MARIA | grep -c "Running")
    echo "Maria is not running : " $KUBE_MARIA
    echo "EXIT"
    exit 0
  else
    kubectl get po --namespace $NAMESPACE | grep $MARIA | grep "Running"
fi

echo -e "\n\n>>>>>> install MANO-Portal Project <<<<<<"
helm install $PORTAL $PWD/chart --namespace $NAMESPACE
# helm install $PORTAL local/mano-portal --namespace $NAMESPACE
# TODO: while문으로 portal running 체크 함수 생성

echo "EXIT"
exit 0