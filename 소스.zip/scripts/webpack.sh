# npm run build
npx webpack -p --watch