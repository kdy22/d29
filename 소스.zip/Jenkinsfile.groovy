// scripted pipeline
node {
  def portal = 'portal'
  def namespace = 'gigamec-mano'
  def repository = 'mec-repo'
  def port = '5000'
  def image = 'mano-portal'
  def version = '0.0.7'
  def helm = 'local'

  stage ('Ready') {
    git 'http://www.kpst.co.kr:30000/markruler/mano-portal.git/'

    try {
      sh "sudo kill -9 \$(sudo lsof -i :19090 | grep -i 19090 | awk \'{print \$2}\')"
    }
    catch (exc) {
      echo exc.getMessage()
      echo "catch: 19090 port-forward not exists."
    }
  }

  dir ('cli') {
    // stage ('build') {
    //   sh './build-image.sh'
    // }

    stage ('print') {
      print(image)
    }

  }
}

void print(message) {
  echo "${message}"
}