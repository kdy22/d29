package com.wizontech.manoportal.apps.service;

import java.io.IOException;
import java.util.Map;

import com.jcraft.jsch.JSchException;

public interface AppService {

  Map<String, String> remoteSsh(String command) throws JSchException, IOException;

}