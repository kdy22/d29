package com.wizontech.manoportal.apps.controller;

import java.io.IOException;
import java.util.Map;

import com.jcraft.jsch.JSchException;
import com.wizontech.manoportal.apps.model.Command;
import com.wizontech.manoportal.apps.service.AppService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import lombok.RequiredArgsConstructor;

// @lombok.extern.slf4j.Slf4j
@RequiredArgsConstructor
@RequestMapping("/app")
@Controller
public class AppController {

  private final AppService appService;
  // private final String NAMESPACE = "--namespace gigamec-mano";

  @PostMapping("/command")
  @ResponseBody
  public ResponseEntity<Map<String, String>> commandRemoteSsh(@RequestBody Command command) throws JSchException, IOException {
    // log.debug("command : {}", command.getCommand());
    Map<String, String> json = appService.remoteSsh(command.getCommand());
    return new ResponseEntity<>(json, HttpStatus.OK);
  }

  @PostMapping("/install/{app}")
  @ResponseBody
  public ResponseEntity<Map<String, String>> commandInstall(@PathVariable String app) throws JSchException, IOException {
    StringBuilder install = new StringBuilder("helm install ");
    switch (app) {
      case "apache":
        install.append("apache local/apache ");
        install.append("--namespace user-app");
        break;
      case "maria":
        install.append("maria local/mariadb ");
        install.append("--namespace user-app");
        break;
      case "etri-sim":
        install.append("simulation-service local/simulation-service ");
        install.append("--namespace simulation-service");
        break;
      case "wizontech-sim":
        install.append("mano-sim local/mano-sim ");
        install.append("--namespace gigamec-mano");
        break;
      default:
        break;
    }
    // log.debug("install : {}", install);

    Map<String, String> json = appService.remoteSsh(install.toString());
    return new ResponseEntity<>(json, HttpStatus.OK);
  }

  @PostMapping("/delete/{app}")
  @ResponseBody
  public ResponseEntity<Map<String, String>> commandDelete(@PathVariable String app) throws JSchException, IOException {
    StringBuilder delete = new StringBuilder("helm uninstall ");
    switch (app) {
      case "apache":
        delete.append("apache ");
        delete.append("--namespace user-app");
        break;
      case "maria":
        delete.append("maria ");
        delete.append("--namespace user-app");
        break;
      case "etri-sim":
        delete.append("simulation-service local/simulation-service ");
        delete.append("--namespace simulation-service");
        break;
      case "wizontech-sim":
        delete.append("mano-sim local/mano-sim ");
        delete.append("--namespace gigamec-mano");
        break;
      default:
        break;
    }
    // log.debug("delete : {}", delete);

    Map<String, String> json = appService.remoteSsh(delete.toString());
    return new ResponseEntity<>(json, HttpStatus.OK);
  }
}