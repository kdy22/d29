package com.wizontech.manoportal.k8s.model;

public abstract class K8sObject {}